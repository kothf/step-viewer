Thermal map of the EL84 test board (fixture). Open it in MöbiusCAD together with amp.step.
